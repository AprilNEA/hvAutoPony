// ==UserScript==
// @name         Horse_support_isekai
// @description  Just collect pony pictures.
// @include      http*://hentaiverse.org/*
// @include      http://alt.hentaiverse.org/*
// @compatible   Firefox + Greasemonkey
// @compatible   Chrome/Chromium + Tampermonkey
// @compatible   Android + Firefox + Usi/Tampermonkey
// @compatible   Other + Bookmarklet
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @run-at       document-end
// @connect      localhost
// ==/UserScript==
/* eslint-disable camelcase */

(function init () {
    if (gE('#riddlebot')) {
      autoanswer()
    }
  })()
  
  function gE (ele, mode, parent) {
    if (typeof ele === 'object') {
      return ele
    } else if (mode === undefined && parent === undefined) {
      return (isNaN(ele * 1)) ? document.querySelector(ele) : document.getElementById(ele)
    } else if (mode === 'all') {
      return (parent === undefined) ? document.querySelectorAll(ele) : parent.querySelectorAll(ele)
    } else if (typeof mode === 'object' && parent === undefined) {
      return mode.querySelector(ele)
    }
  }
  
  function autoanswer (){
      //var uuid="18ed40fb-4491-4083-b0e3-2cf16d3fbc55"
      //var aaaa = document.getElementById("riddlebot").getElementsByTagName("img")[0].getAttribute("src")
      //if(aaaa.search("isekai")!=-1){aaaa=aaaa+'_isekai'}
      //var cccc=aaaa.split("?")
      var urla='http://127.0.0.1:5000/api'
      GM_xmlhttpRequest ( {
          method:     "Post",
          url:        urla,
          onload:     function (response) {
              var rp=response.responseText
              if (rp=="A"||rp=="B"||rp=="C"){
                  gE('#riddleanswer').value=rp
                  gE('#riddleanswer+img').click()
              }
          }
      } )
  }

var httpRequest = new XMLHttpRequest();//第一步：创建需要的对象
httpRequest.open('POST', 'http://127.0.0.1:5000/api', true); //第二步：打开连接/***发送json格式文件必须设置请求头 ；如下 - */
httpRequest.setRequestHeader("Content-type","application/json");//设置请求头 注：post方式必须设置请求头（在建立连接后设置请求头）var obj = { name: 'zhansgan', age: 18 };
httpRequest.send(JSON.stringify(obj));//发送请求 将json写入send中
/**
 * 获取数据后的处理程序
 */
httpRequest.onreadystatechange = function () {//请求后的回调接口，可将请求成功后要执行的程序写在其中
    if (httpRequest.readyState == 4 && httpRequest.status == 200) {//验证请求是否发送成功
        var json = httpRequest.responseText;//获取到服务端返回的数据
        console.log(json);
    }
};