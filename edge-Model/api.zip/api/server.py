from autopony import autopony
from flask import jsonify
from flask import Flask
from flask import request
import json



from flask_cors import cross_origin
app = Flask(__name__)
@app.route('/api', methods=['Post'])
@cross_origin()
def get_tasks():
    #base64 = str(request.values.get("base64"))
    data = request.get_data(as_text=True)
    data = json.loads(str(data))
    base64 = data["base64"]
    answer = autopony(base64)  # 输入base64小马图，输出A\B\C
    back = {
        'return': [
            {'answer': answer,
             'key': '1'}
        ]
    }
    return answer
if __name__ == '__main__':
    app.run(host="127.0.0.1", port=5000, debug=True)


